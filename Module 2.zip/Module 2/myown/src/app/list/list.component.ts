import { Component, OnInit } from '@angular/core';
import { Data,MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  service:MyserviceService;
    constructor(service:MyserviceService) {
      this.service=service;
     }
     data:Data[]=[];
     delete(id:number){
      this.service.delete(id);
      this.data=this.service.getData();
    }
  ngOnInit() {
    this.service.search();
    this.data=this.service.getData();
  }
}
