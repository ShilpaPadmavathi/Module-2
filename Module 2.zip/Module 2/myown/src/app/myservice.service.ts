import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
http:HttpClient;
data:Data[]=[];
  constructor(http:HttpClient) {
    this.http=http;
    this.search();
   }
   fetch:boolean=false;
   search(){
    this.http.get('./assets/db.json').subscribe(
      data=>{
        if(!this.fetch){
          this.catch(data);
           this.fetch=true;
        }

      });
   }
   delete(id:number){
    let foundIndex:number=-1;
    for(let i=0;i<this.data.length;i++){
      let e=this.data[i];
      if(id==e.id){
        foundIndex=i;
        break;
      }

   }
  }
   getData():Data[]{
    return this.data;
  }
   catch(data:any){
    for(let o of data["products"]){
      let e=new Data(o.id,o.name,o.price,o.category);
      this.data.push(e);
   } 
}
}
export class Data{
  id:number;
  name:string;
  price:number;
  category;string;
  constructor( id,name,price,category) {
    this.id=id;
    this.name=name;
    this.price=price;
    this.category=category;
   }

}