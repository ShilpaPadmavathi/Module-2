import { Component, OnInit } from '@angular/core';
import { Data,MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  createdData:Data;
  createdFlag=false;

  service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service;
   }
  
  ngOnInit() {
  }
  search(data:any){
    if(this.createdData.id==data.id){
    this.service.search(data);
    this.createdFlag=true;
    }

  }


}
