import { Component, OnInit } from '@angular/core';
import { ModuleServiceService } from '../module-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  createdEmployee:Employee;
  service:ModuleServiceService;

createdFlag:boolean=false;

  constructor() { }

  ngOnInit() {
  }
  add(data:any){
    this.createdEmployee=new Employee(data.id,data.name,data.des,data.salary);
    this.service.add(this.createdEmployee);
    this.createdFlag=true;
  }

}
