import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ModuleServiceService {
  http:HttpClient;
  create:Create[]=[];
  constructor(http:HttpClient) {
    this.http=http;
   }
   add(data:any){
    this.create.push(data);
  }
}
export class Create{
  username:string;
  password:string;
  mobile:number;
  balance:number;
  constructor(username:string,password:string,mobile:number,balance:number){
    this.username=username;
    this.password=password;
    this.mobile=mobile;
    this.balance=balance;
  }
}