import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{HttpClient,HttpClientModule}from '@angular/common/http'; 
import {ModuleServiceService} from './module-service.service'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import{FormsModule} from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    CreateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,ModuleServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
