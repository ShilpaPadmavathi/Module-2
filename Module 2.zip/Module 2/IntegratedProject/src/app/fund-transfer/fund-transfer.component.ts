import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin: boolean = true;
  isShowBalance=true;
  cbalance1:number;
  service: MyServiceService;
  constructor(service: MyServiceService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  fundTransfer(data: any) {
    if(data.caccount=="" || data.caccount1==""|| data.cpassword=="" ||data.cbalance ==""){
      alert("Please fill all Fields")
      return;
    }
    let caccount_first = data.caccount;
    let caccount_second = data.caccount2;
    let cbalance = data.cbalance;
    if (this.service.login(data)) {
      
      this.service.fundTransfer(caccount_first,caccount_second, cbalance);
      
     
     this.cbalance1=cbalance
 
      this.isShowBalance =false;
    }
    else {
      alert("Wrong Account Number or Password");
    }
  }

  ngOnInit() {
  }

}
