import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee } from '../my-service.service';


@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  isLogin: boolean = true;
  employees: Employee[] = [];
  cbalance: number;
  isShowBalance: boolean = true;

  service: MyServiceService;
  constructor(service: MyServiceService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  showBalance(data: any) {
    if(data.caccount=="" ||  data.cpassword=="" ){
      alert("Please fill all Fields")
      return;
    }
    if (this.service.login(data)) {
      let data1= this.service.showBalance(data);
      data1.subscribe((data2)=>this.cbalance=data2.balance)
 
      this.isShowBalance = false;
    }
    else {
      alert("Wrong Account Number or Password")
    }

  }

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees = this.service.getEmployees();
  }




}
