import { Component, OnInit } from '@angular/core';
import { MyServiceService} from '../my-service.service';
import { Employee } from '../my-service.service';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  employees: Employee[] = [];
  service: MyServiceService;
tran:any;
emp:Employee;
tran1:any[];
  constructor(service: MyServiceService) {
    this.service = service;
    
  }

  mini(data: any) {
    if(data.caccount=="" ||data.cpassword==""){
      alert("Please fill all Fields")
      return;
    }
    if (this.service.login(data)) {
      var obj = this.service.mini(data);
      console.log(obj)
      obj
        .subscribe((data) => {
          console.log("inside sub")
          console.log(data.tran)
          this.tran = data.tran;
          this.tran1=this.tran.split(" ")
          console.log(this.tran1)
        },(error) => {
          console.log(error)
        })
     // console.log(this.emp)
    }
    else {
      alert("Wrong Account Number or Password")
    }
  }

  ngOnInit() {

    

  }

}
