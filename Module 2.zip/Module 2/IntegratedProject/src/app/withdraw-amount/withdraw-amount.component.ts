import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee} from '../my-service.service';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {


  isLogin: boolean = true;
  employees: Employee[] = [];
isShowBalance=true;
cbalance1:number;
cbalance2:number;
  service: MyServiceService;
  constructor(service: MyServiceService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
    
  }

  withdrawAmount(data: any) {
    if(data.caccount=="" ||  data.cpassword=="" ||data.cbalance ==""){
      alert("Please fill all Fields")
      return;
    }
    let tid: number;
    let caccount_first: number = data.caccount;
    this.cbalance1 = data.cbalance;

    if (this.service.login(data)) {
      this.service.withdrawBalance(caccount_first, data.cbalance);

      let data1= this.service.showBalance(data);
      data1.subscribe((data2)=>this.cbalance2=data2.balance)
 
      this.isShowBalance =false;
    }
    else {
      alert("Wrong Account Number or Password");
    }
  }

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees = this.service.getEmployees();
  }
}
