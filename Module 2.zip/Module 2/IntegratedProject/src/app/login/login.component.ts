import { Component, OnInit } from '@angular/core';

import { MyServiceService} from '../my-service.service';
import { Employee } from '../my-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  employees: Employee[] = [];
  service: MyServiceService;
router:Router

  constructor(service: MyServiceService,router:Router) {
    this.service = service;
    this.router=router;
  }

  ngOnInit() {this.employees = this.service.getEmployees();
  }
  login(data:any){
    let caccount=data.caccount;
    let cpassword=data.cpassword;
    if(this.service.login(data)){
 
    // this.service.acc=caccount;
    this.router.navigate(['app-Loggedinpage']);}
    else{
      alert("Enter correct Account number or password")
    }
}
}
