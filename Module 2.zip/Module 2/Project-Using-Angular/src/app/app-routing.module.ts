import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UiComponent } from './Create/ui.component'
import { DisplaybalanceComponent } from './displaybalance/displaybalance.component';
import { DepositamountComponent } from './depositamount/depositamount.component';
import { WithdrawamountComponent } from './withdrawamount/withdrawamount.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrinttransactionsComponent } from './printtransactions/printtransactions.component';
import { DisplayComponent } from './display/display.component';
import { StartComponent } from './start/start.component';
import {FormsModule} from '@angular/forms';
import {OurserviceService} from './ourservice.service';
import {ServicesService} from './services.service';
import { HomeComponent } from './home/home.component';
const routes: Routes = [
  {
    path:'app-home',
    component : HomeComponent
  },
  {
    path:'app-ui',
    component : UiComponent
  },
  {
    path:'app-depositamount',
    component : DepositamountComponent
  },
  {
    path:'app-display',
    component : DisplayComponent
  },
  {
    path:'app-displaybalance',
    component : DisplaybalanceComponent
  },
  {
    path:'app-fundtransfer',
    component : FundtransferComponent
  },
  {
    path:'app-printtransactions',
    component : PrinttransactionsComponent
  },
  {
    path:'app-start',
    component : StartComponent
  },
  {
    path:'app-withdrawamount',
    component : WithdrawamountComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
