import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UiComponent } from './Create/ui.component'
import { DisplaybalanceComponent } from './displaybalance/displaybalance.component';
import { DepositamountComponent } from './depositamount/depositamount.component';
import { WithdrawamountComponent } from './withdrawamount/withdrawamount.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrinttransactionsComponent } from './printtransactions/printtransactions.component';
import { DisplayComponent } from './display/display.component';
import { StartComponent } from './start/start.component';
import {FormsModule} from '@angular/forms';
import {OurserviceService} from './ourservice.service';
import {ServicesService} from './services.service';
import { ShowPipe } from './show.pipe';
import { HomeComponent } from './home/home.component';


@NgModule({
  declarations: [
    AppComponent,
    UiComponent,
    DisplaybalanceComponent,
    DepositamountComponent,
    WithdrawamountComponent,
    FundtransferComponent,
    PrinttransactionsComponent,
    DisplayComponent,
    StartComponent,
    ShowPipe,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,OurserviceService,ServicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
