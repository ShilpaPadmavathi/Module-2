import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displaybalance',
  templateUrl: './displaybalance.component.html',
  styleUrls: ['./displaybalance.component.css']
})
export class DisplaybalanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
