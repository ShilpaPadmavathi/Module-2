import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaybalanceComponent } from './displaybalance.component';

describe('DisplaybalanceComponent', () => {
  let component: DisplaybalanceComponent;
  let fixture: ComponentFixture<DisplaybalanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplaybalanceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplaybalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
