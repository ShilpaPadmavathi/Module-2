import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Users} from 'src/app/Functionalities/Users';
import {Transactions} from 'src/app/Functionalities/Transactions';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class OurserviceService {
  http:HttpClient;
  isLogin:boolean=true;
  users:Users[]=[];
  transfers:Transactions[]=[];
  tempTransfers:Transactions[]=[];
  fetched:boolean=false;
  transaction:boolean=false;
  account:number=0;

  private check = new BehaviorSubject('');
  currentMessage = this.check.asObservable();

  changeMessage(message: string) {
    this.check.next(message)
  }

  constructor(http:HttpClient) { 
    this.http=http;
    this.getUsers();
    this.userTransaction();
  }

  getUsers()
  {
    this.http.get('./assets/Users.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.change(data);
          this.fetched=true;
        }
      }
    );
  }

  change(data:any)
  {
    for(let o of data)
    {
      let e=new Users(o.createAccount,o.username,o.userphone,
        o.userpassword,o.usercity,o.userBalance);
      this.users.push(e);
    }
  }

  userTransaction()
  {
    this.http.get('./assets/Transactions.json')
    .subscribe
    (
      data=>
      {
        if(!this.transaction)
        {
          this.convertTransaction(data);
          this.transaction=true;
        }
      }
    );
  }

  convertTransaction(user:any)
  {
    for(let d of user)
    {
      let e=new Transactions(d.transid,d.transsender,
        d.transreciver,d.transamount,d.transtype);
      this.transfers.push(e);
      console.log(this.transfers)
    }
  }

  getCustomers():Users[]
  {
    return this.users;
  }

  getTransactions():Transactions[]
  {
    return this.transfers;
  }

  miniStatement(createAccount:number):Transactions[]{
    this.tempTransfers=[];
    for(let i=0;i<this.transfers.length;i++)
    {
      let e=this.transfers[i];
      if(createAccount==e.transsender)
      {
        this.tempTransfers.push(e);
      }
    }
    return this.tempTransfers;
  }

  add(e:Users){
    this.users.push(e);
    var myJSON = JSON.stringify(this.users);
  }

  addTransaction(e:Transactions){
    this.transfers.push(e);
    console.log(this.transfers)
  }

  showBalance():number{
    for(let i=0;i<this.users.length;i++)
      {
        if(this.account == this.users[i].createAccount)
        {
          let userBalance=this.users[i].userBalance;
          alert("Current Balance : "+userBalance)
          return userBalance;
        }else{
          continue;
        }
      }
      alert("Account Number is Wrong")
  }

  depositeBalance(caccount_second:number,cbalance:number):boolean{

    for(let i=0;i<this.users.length;i++)
    {
      if(this.account == this.users[i].createAccount)
      {
        let depositeB:number=this.users[i].userBalance;
        this.users[i].userBalance=parseInt(depositeB.toString()) + parseInt(cbalance.toString());
        alert("Amount Deposited from "+this.account+"\nUpdated Balance : "+this.users[i].userBalance);
        return true;
      }else if(caccount_second == this.users[i].createAccount){
        let depositeB:number=this.users[i].userBalance;
        this.users[i].userBalance=parseInt(depositeB.toString()) + parseInt(cbalance.toString());
        alert("The Deposited Amount is"+this.account+"\nUpdated Balance : "+this.users[i].userBalance);
        return true;
      }else{
        continue;
      }
    }
      alert("Please Login First")
  }

  withdrawBalance(cbalance:number){

    for(let i=0;i<this.users.length;i++)
    {
      if(this.account == this.users[i].createAccount)
      {
        let depositeB:number=this.users[i].userBalance;
        this.users[i].userBalance=parseInt(depositeB.toString()) - parseInt(cbalance.toString());
        alert("Amount Deposited from "+this.account+"\nUpdated Balance : "+this.users[i].userBalance);
        return true;
      }else{
        continue;
      }
    }
      alert("Please Login to the Application")
  }

  login(data:Users):boolean
  {
    this.account=data.createAccount;
    let password=data.userpassword;

    for(let e of this.users)
    {
      console.log(this.users)
      if(this.account == e.createAccount && password == e.userpassword)
      {
       
        alert("Data Matches!")
        this.isLogin=!this.isLogin;
        this.changeMessage('loginhai');
        return true;
      }else {
        continue;
      }
      
    }
    return false; 
  }

}
