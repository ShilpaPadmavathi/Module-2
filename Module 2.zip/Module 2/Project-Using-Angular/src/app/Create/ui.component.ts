import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {OurserviceService} from 'src/app/ourservice.service';
import {Users} from 'src/app/Functionalities/Users';
import {Transactions} from 'src/app/Functionalities/Transactions';

@Component({
  selector: 'app-ui',
  templateUrl: './ui.component.html',
  styleUrls: ['./ui.component.css']
})
export class UiComponent implements OnInit {
  createdUsers:Users;
  createdTransaction:Transactions;
  router:Router;
  service:OurserviceService;
  flag:boolean=false;

  constructor(service:OurserviceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }
  add(d:any){
    d.createAccount=Math.floor(Math.random() * 10) + 4326 
    let transId=Math.floor(Math.random() * 10) + 7985 ;
    d.userBalance=3500;
    
    this.createdUsers=new Users(d.createAccount,d.username,d.userphone,
      d.userpassword,d.usercity,d.userBalance);
    this.service.add(this.createdUsers);
    
    this.createdTransaction=new Transactions(transId,d.createAccount,0,d.userBalance,"Account Creation");
    this.service.addTransaction(this.createdTransaction)
    console.log(this.createdTransaction);

    alert("Added Succesfully!!!");
    this.flag=true;
    this.router.navigate(['app-start']);
   }
   ngOnInit() {
  }

}
