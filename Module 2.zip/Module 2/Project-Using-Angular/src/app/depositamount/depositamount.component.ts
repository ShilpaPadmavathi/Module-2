import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-depositamount',
  templateUrl: './depositamount.component.html',
  styleUrls: ['./depositamount.component.css']
})
export class DepositamountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
