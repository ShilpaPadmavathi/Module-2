import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositamountComponent } from './depositamount.component';

describe('DepositamountComponent', () => {
  let component: DepositamountComponent;
  let fixture: ComponentFixture<DepositamountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepositamountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositamountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
