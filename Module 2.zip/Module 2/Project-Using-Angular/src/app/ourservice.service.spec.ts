import { TestBed } from '@angular/core/testing';

import { OurserviceService } from './ourservice.service';

describe('OurserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OurserviceService = TestBed.get(OurserviceService);
    expect(service).toBeTruthy();
  });
});
