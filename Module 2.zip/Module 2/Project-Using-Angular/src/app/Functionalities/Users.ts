export class Users{
    createAccount:number;
    username:string;
    userphone:number;
    userpassword:string;
    usercity:string;
    userBalance:number;
  
      constructor(createAccount:number,username:string,userphone:number,userpassword:string,
        usercity:string,userBalance:number)
      {
        this.userBalance=userBalance;
        this.createAccount=createAccount;
        this.username=username;
        this.userphone=userphone;
        this.userpassword=userpassword;
        this.usercity=usercity;
      }
  }