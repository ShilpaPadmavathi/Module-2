export class Transactions{
    transid:number;
    transsender:number;
    transreciver:number;
    transamount:number;
    transtype:string;
  
  
      constructor(transid:number,transsender:number,transreciver:number,
        transamount:number,transtype:string)
      {
        this.transid=transid;
        this.transsender=transsender;
        this.transreciver=transreciver;
        this.transamount=transamount;
        this.transtype=transtype;
      }
  }