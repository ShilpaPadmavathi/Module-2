import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyDateComponent } from './my-date/my-date.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmpbuttonComponent } from './empbutton/empbutton.component';
import { EmptwowayComponent } from './emptwoway/emptwoway.component';
import { Pipe1Pipe } from './emptwoway/pipe1.pipe';
import { DirDirective } from './emptwoway/dir.directive';
import { SalPipe } from './emptwoway/sal.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MyDateComponent,
    EmployeeComponent,
    EmpbuttonComponent,
    EmptwowayComponent,
    Pipe1Pipe,
    DirDirective,
    SalPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
