import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../employee/Employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {


  ngOnInit() {
  }
  @Input("empObj")employeeObj:Employee;
  emp:any[];
  constructor() { 
      this.emp=[{eid:1221,ename:"Shilpa",edesignation:"Analyst",
      eaddress:"Hyderabad",econtact:8317580045},
    {eid:1203,ename:"Pappu",edesignation:"Student",eaddress:"Hyderabad",
    econtact:7680829466}];
    }
   
  }
