import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-date',
  templateUrl: './my-date.component.html',
  styleUrls: ['./my-date.component.css']
})
export class MyDateComponent implements OnInit {
  date1:string;
  constructor() { 
  this.date1=new Date().toString();
  setInterval(()=>{let myDate1=new Date();
  this.date1=myDate1.toDateString()+" "+myDate1.toLocaleTimeString()},1000);
  }
  ngOnInit() {
  }
}