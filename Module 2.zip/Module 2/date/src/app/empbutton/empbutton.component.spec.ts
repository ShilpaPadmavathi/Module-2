import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpbuttonComponent } from './empbutton.component';

describe('EmpbuttonComponent', () => {
  let component: EmpbuttonComponent;
  let fixture: ComponentFixture<EmpbuttonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmpbuttonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpbuttonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
