import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../employee/Employee';
@Component({
  selector: 'app-empbutton',
  templateUrl: './empbutton.component.html',
  styleUrls: ['./empbutton.component.css']
})
export class EmpbuttonComponent implements OnInit {

  

  ngOnInit() {
  }
  @Input("emp1Obj")employObj:Employee;
  iscollapsed:boolean=true;
  check(){
    this.iscollapsed=!this.iscollapsed;
  }
  constructor() { }

}
