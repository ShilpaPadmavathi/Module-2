import { Component } from '@angular/core';

import { Employee } from './employee/Employee';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'date';
  emp2:Employee;
constructor(){
  this.emp2=new Employee();
  this.emp2.eid=1203;
  this.emp2.ename="Pappu";
  this.emp2.edesignation="Analyst";
  this.emp2.eaddress="Hyderabad";
  this.emp2.econtact=["7680829466","8919953768"];

}
  }