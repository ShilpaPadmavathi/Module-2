import { DirDirective } from './dir.directive';

describe('DirDirective', () => {
  it('should create an instance', () => {
    const directive = new DirDirective();
    expect(directive).toBeTruthy();
  });
});
