import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmptwowayComponent } from './emptwoway.component';

describe('EmptwowayComponent', () => {
  let component: EmptwowayComponent;
  let fixture: ComponentFixture<EmptwowayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmptwowayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmptwowayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
