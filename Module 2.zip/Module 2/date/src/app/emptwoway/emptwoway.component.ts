import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emptwoway',
  templateUrl: './emptwoway.component.html',
  styleUrls: ['./emptwoway.component.css']
})
export class EmptwowayComponent implements OnInit {
Employee:any;
hello:string="welcome";
  constructor() { 
    this.Employee={
      FirstName:"Shilpa",
      LastName:"Padmavathi",
      Gender:"female",
      date:new Date(),
      salary:500000,
      months:12
    };
   }
  ngOnInit() {
  }

}
