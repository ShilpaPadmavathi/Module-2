import { SalPipe } from './sal.pipe';

describe('SalPipe', () => {
  it('create an instance', () => {
    const pipe = new SalPipe();
    expect(pipe).toBeTruthy();
  });
});
