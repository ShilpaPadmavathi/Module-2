import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sal'
})
export class SalPipe implements PipeTransform {

  transform(value: number,salary:number): string {
    if(salary<=18000){
    return value+"not Eligible";
  }
  else
  return value+"Eligible";

}
}
