import { Component, OnInit } from '@angular/core';
import { Management,MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  management:Management;
flag:boolean=false;
service:MyserviceService;//Creating the Service class Object
  constructor(service:MyserviceService) {
    this.service=service;
   }

  ngOnInit() {
    
  }
  add(data:any){ //Function for Adding the Data
    this.management=new Management(data.id,data.name,data.email,data.phone);//adding the data to constructor
    this.service.add(this.management);//calling the service class add method
    alert("Added Succesfully!!!");//Alert Message to know if data is added Successfully
    this.flag=true;
  }

  }
