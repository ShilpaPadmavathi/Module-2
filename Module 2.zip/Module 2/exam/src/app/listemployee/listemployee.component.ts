import { Component, OnInit } from '@angular/core';
import { Management,MyserviceService } from '../myservice.service';
@Component({
  selector: 'app-listemployee',
  templateUrl: './listemployee.component.html',
  styleUrls: ['./listemployee.component.css']
})
export class ListemployeeComponent implements OnInit {
  service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service;
    
   }
   manage:Management[]=[];
   delete(id:number){ /*Creating a method for deleting the Data*/
     this.service.delete(id);
     this.manage=this.service.getDetails();/*calling the getdetails 
     method of service class for fetching the Data*/
   }
  ngOnInit() {
    this.service.fetchDetails();//Calling the fetch details method of service class
    this.manage=this.service.getDetails();
  }

}
