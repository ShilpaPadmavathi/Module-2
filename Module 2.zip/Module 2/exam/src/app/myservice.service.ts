import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  http:HttpClient;
  manage:Management[]=[];//Creating an object for Management class
  constructor(http:HttpClient) {
    this.http=http;
   }
   fetch:boolean=false;
   fetchDetails(){/*Method for fetching the details from json and storing the json data 
    in data*/ 
     this.http.get('./assets/employees.json').subscribe(
       data=>{
         if(!this.fetch){
           this.change(data);
           this.fetch=true;
         }
       }
     );
   }
   getDetails():Management[]{//for returning the details of the object in manage 
    return this.manage;
  }
  change(data:any){//converting the json data into the normal format
    for(let o of data){
      let e=new Management(o.id,o.name,o.email,o.phone);
      this.manage.push(e);
    }
  }
  delete(id:number){//method for deleting the data
    let foundIndex:number=-1;
    for(let i=0;i<this.manage.length;i++){
      let m=this.manage[i];
      if(id==m.id){
        foundIndex=i;
        break;
      }
    }
  
    this.manage.splice(foundIndex,1);
  }
  add(data:any){// for adding the data 
    this.manage.push(data);
  }

}
export class Management{//Another Class with constructor for storing the data
  id:number;
  name:string;
  email:string;
  phone:number;
  constructor(id:number,name:string,email:string,phone:number){
    this.id=id;
    this.name=name;
    this.email=email;
    this.phone=phone;
  }
}

