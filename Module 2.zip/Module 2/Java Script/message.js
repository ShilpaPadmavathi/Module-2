function msg(){
    document.write("WELCOME SHILPA");
}